<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Category extends Model
{
    protected $fillable = ['parent_id','name','slug','description','is_active','sort_order'];
    protected function casts(): array { return ['name' => 'array','description' => 'array','is_active' => 'boolean']; }
    public function products(): HasMany { return $this->hasMany(Product::class); }
    public function children(): HasMany { return $this->hasMany(self::class, 'parent_id'); }
}
