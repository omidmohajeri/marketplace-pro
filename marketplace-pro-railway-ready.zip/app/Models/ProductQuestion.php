<?php
// مدل پرسش و پاسخ محصول
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class ProductQuestion extends Model {
 protected $fillable=['product_id','user_id','question','answer','answered_by','status'];
 public function product(): BelongsTo { return $this->belongsTo(Product::class); } // محصول
 public function user(): BelongsTo { return $this->belongsTo(User::class); } // پرسشگر
 public function answerer(): BelongsTo { return $this->belongsTo(User::class,'answered_by'); } // پاسخ‌دهنده
}