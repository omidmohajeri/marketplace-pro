<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('order_items', function (Blueprint $table) {
            $table->id(); $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('seller_id')->nullable()->constrained()->nullOnDelete();
            $table->json('product_name'); $table->string('sku'); $table->unsignedInteger('quantity');
            $table->unsignedBigInteger('unit_price'); $table->unsignedBigInteger('line_total'); $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('order_items'); }
};
