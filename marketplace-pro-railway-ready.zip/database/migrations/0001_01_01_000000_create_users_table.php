<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('users', function (Blueprint $table) {
            $table->id(); $table->string('name'); $table->string('email')->unique()->nullable();
            $table->string('phone', 30)->unique()->nullable(); $table->timestamp('email_verified_at')->nullable();
            $table->string('password'); $table->enum('role', ['customer','seller','admin'])->default('customer');
            $table->string('locale', 5)->default('fa'); $table->rememberToken(); $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('users'); }
};
